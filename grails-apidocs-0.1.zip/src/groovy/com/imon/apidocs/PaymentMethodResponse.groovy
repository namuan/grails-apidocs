package com.imon.apidocs

class PaymentMethodResponse {
    String type
    String paymentInfo
}
