package com.imon.apidocs

class HttpVerb {
    String name
    String title
    String controllerMethod
    String notes
    Class responseClass
}
