package com.imon.apidocs

class ApiRegistry {
    static endpoints = [:]
}
